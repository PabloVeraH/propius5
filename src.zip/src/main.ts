import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,              // elimina propiedades no declaradas en DTO
      forbidNonWhitelisted: true,   // lanza 400 si vienen propiedades extra
      transform: true,              // transforma payload a instancias de DTO
      transformOptions: { enableImplicitConversion: true },
      stopAtFirstError: true,       // opcional: falla en el primer error
      // enableErrorMessages: process.env.NODE_ENV !== 'production',
    }),
  );
  
  await app.listen(process.env.PORT ?? 3000);
}
bootstrap();
